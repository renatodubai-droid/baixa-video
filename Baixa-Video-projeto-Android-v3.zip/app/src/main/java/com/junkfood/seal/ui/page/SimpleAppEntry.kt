package com.junkfood.seal.ui.page

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.junkfood.seal.download.DownloaderV2
import com.junkfood.seal.download.Task
import com.junkfood.seal.util.CONVERT_MP3
import com.junkfood.seal.util.DownloadUtil
import com.junkfood.seal.util.FORMAT_COMPATIBILITY
import com.junkfood.seal.util.matchUrlFromSharedText
import org.koin.compose.koinInject

private enum class SimpleFormat { VIDEO, AUDIO }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleAppEntry(
    incomingUrl: String,
    downloader: DownloaderV2 = koinInject(),
) {
    var url by remember { mutableStateOf("") }
    var format by remember { mutableStateOf(SimpleFormat.VIDEO) }
    var message by remember { mutableStateOf("Cole o link do vídeo para começar") }
    var activeTaskId by rememberSaveable { mutableStateOf<String?>(null) }
    var submitting by remember { mutableStateOf(false) }
    var pendingTask by remember { mutableStateOf<Task?>(null) }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        pendingTask?.let { downloader.enqueue(it) }
        pendingTask = null
        if (!granted) message = "Notificações desativadas. O progresso continuará nesta tela."
    }
    val activeDownloadState =
        downloader.getTaskStateMap().entries
            .firstOrNull { it.key.id == activeTaskId }?.value?.downloadState
    val isBusy =
        submitting || activeDownloadState == Task.DownloadState.Idle ||
            activeDownloadState is Task.DownloadState.FetchingInfo ||
            activeDownloadState is Task.DownloadState.ReadyWithInfo ||
            activeDownloadState is Task.DownloadState.Running

    LaunchedEffect(activeDownloadState) {
        when (val state = activeDownloadState) {
            Task.DownloadState.Idle, is Task.DownloadState.FetchingInfo,
            Task.DownloadState.ReadyWithInfo -> message = "Analisando o link e preparando o download…"
            is Task.DownloadState.Running -> {
                submitting = false
                val percent = if (state.progress >= 0f) "${(state.progress * 100).toInt()}%" else ""
                message = if (percent.isEmpty()) "Baixando… ${state.progressText}".trim()
                    else "Baixando… $percent${state.progressText.takeIf { it.isNotBlank() }?.let { " • $it" } ?: ""}"
            }
            is Task.DownloadState.Completed -> {
                submitting = false
                message = "Download concluído. Salvo em: ${state.filePath ?: "pasta de downloads configurada"}"
            }
            is Task.DownloadState.Error -> {
                submitting = false
                message = "Falha no download: ${state.throwable.message ?: "verifique o link e tente novamente"}"
            }
            is Task.DownloadState.Canceled -> {
                submitting = false
                message = "Download cancelado"
            }
            null -> Unit
        }
    }

    LaunchedEffect(incomingUrl) {
        if (incomingUrl.isNotBlank()) url = incomingUrl
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().statusBarsPadding(),
        topBar = {
            TopAppBar(
                title = {
                    Text("Baixa Vídeo", fontWeight = FontWeight.Bold)
                }
            )
        },
    ) { padding ->
        Column(
            modifier =
                Modifier.fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.Top,
        ) {
            Text(
                "Baixe na melhor qualidade disponível",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(20.dp))

            OutlinedTextField(
                value = url,
                onValueChange = { url = it.trim() },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Link do vídeo") },
                placeholder = { Text("Cole aqui o link do TikTok, Instagram...") },
                singleLine = true,
                trailingIcon = {
                    androidx.compose.material3.IconButton(
                        onClick = {
                            val copied = clipboard.getText()?.text.orEmpty()
                            url = matchUrlFromSharedText(copied).ifBlank { copied.trim() }
                        }
                    ) {
                        Icon(Icons.Outlined.ContentPaste, contentDescription = "Colar link")
                    }
                },
            )

            Spacer(Modifier.height(18.dp))
            Text("Escolha o formato", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = format == SimpleFormat.VIDEO,
                    onClick = { format = SimpleFormat.VIDEO },
                    label = { Text("Vídeo MP4") },
                    leadingIcon = { Icon(Icons.Outlined.VideoFile, contentDescription = null) },
                )
                FilterChip(
                    selected = format == SimpleFormat.AUDIO,
                    onClick = { format = SimpleFormat.AUDIO },
                    label = { Text("Áudio MP3") },
                    leadingIcon = { Icon(Icons.Outlined.MusicNote, contentDescription = null) },
                )
            }

            Spacer(Modifier.height(22.dp))
            Button(
                onClick = {
                    val cleanUrl = matchUrlFromSharedText(url).ifBlank { url.trim() }
                    if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                        message = "Cole um link válido para baixar"
                        return@Button
                    }

                    val base = DownloadUtil.DownloadPreferences.createFromPreferences()
                    val preferences =
                        if (format == SimpleFormat.AUDIO) {
                            base.copy(
                                extractAudio = true,
                                convertAudio = true,
                                audioConvertFormat = CONVERT_MP3,
                                audioQuality = 0,
                                downloadPlaylist = false,
                            )
                        } else {
                            base.copy(
                                extractAudio = false,
                                videoFormat = FORMAT_COMPATIBILITY,
                                videoResolution = 0,
                                downloadPlaylist = false,
                                mergeToMkv = false,
                            )
                        }

                    val task = Task(url = cleanUrl, preferences = preferences)
                    activeTaskId = task.id
                    submitting = true
                    message = "Analisando o link e preparando o download…"
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                        androidx.core.content.ContextCompat.checkSelfPermission(
                            context, Manifest.permission.POST_NOTIFICATIONS
                        ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                    ) {
                        pendingTask = task
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else downloader.enqueue(task)
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                enabled = url.isNotBlank() && !isBusy,
            ) {
                Icon(Icons.Outlined.Download, contentDescription = null)
                Spacer(Modifier.padding(4.dp))
                Text(
                    if (activeDownloadState is Task.DownloadState.Running) "Baixando…"
                    else if (isBusy) "Preparando…" else "Baixar agora",
                    fontWeight = FontWeight.Bold,
                )
            }

            Spacer(Modifier.height(18.dp))
            if (isBusy) {
                val running = activeDownloadState as? Task.DownloadState.Running
                if (running != null && running.progress >= 0f) {
                    LinearProgressIndicator(
                        progress = { running.progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        pendingTask = null
                        val task = downloader.getTaskStateMap().keys.firstOrNull { it.id == activeTaskId }
                        if (task != null) downloader.cancel(task)
                        else { submitting = false; message = "Download cancelado" }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Cancelar download") }
            }
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Text(
                    message,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyLarge,
                )
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Use apenas em conteúdos que você tem permissão para baixar.",
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    YtdlpUpdater()
}
